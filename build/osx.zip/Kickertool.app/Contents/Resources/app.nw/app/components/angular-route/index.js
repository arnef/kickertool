require('./angular-route');
module.exports = 'ngRoute';
