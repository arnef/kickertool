# Kickertool #

## Download ##
Hier gibts die ausführbaren Programme für die verschiedene Systeme.     
Akutelle Version ist v0.4.0   
* [Linux 32bit](http://arnef.ddns.net/kickertool/dl/kickertool_linux32.zip) / 
 [Linux 64bit](http://arnef.ddns.net/kickertool/dl/kickertool_linux64.zip)      
* [Mac OSX 32 / 64bit](http://arnef.ddns.net/kickertool/dl/kickertool_osx.zip)
* [Windows 32 / 64bit](http://arnef.ddns.net/kickertool/dl/kickertool_win.zip)



## Changelog ##
    
    v0.4.0
    - Updatesuche beim Start
    
    v0.3.1
    - App Icon
    - UI verbessert
    - Dialoge übersetzt
    
    v0.3.0
    - Einzelturnier Modus
    - Festes Doppel Modus
    - Keine Wiederholungen bei Begegnungen der Vorrunde
    - Spiel wird automatisch zurückgestellt, falls eines der Teams noch spielt
        
    v0.2.0
    - Doppelte Spielernamen sind nicht mehr möglich
    - Spiel kann von Tisch zurückgenommen werden
    - K.O. Runde berrechnet Paarungen jetzt korrekt
    - Ergebnisse können korrigiert werden
    - Nächste Vorrunde wird früher berechnet
    
    v0.1.0
    - Fair-For-All DYP Modus
    - Schweizer-Vorrunde
    
